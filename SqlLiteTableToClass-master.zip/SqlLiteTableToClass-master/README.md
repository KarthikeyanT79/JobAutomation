# SQLite To C# Class Generator
This Utility will convert your SQLite tables to C# class.

Steps To Generate C# Class:

1) Specify SQLite database file, it will show up all tables.

2) Select table from drop down.

3) Click generate

4) It will ask to save .cs file destination, save at your desired location.
![alt text](https://raw.githubusercontent.com/Adildev/SqlLiteTableToClass/master/Sample.png)
