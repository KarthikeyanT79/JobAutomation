# Steps To Generate C# Class:

# Specify SQLite database file, it will show up all tables.
# Select table from drop down.
# Click generate
# It will ask to save .cs file destination, save at your desired location.*